
async function loadPrices(){
  try{
    const response = await fetch(
      "https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ethereum,solana,binancecoin&vs_currencies=usd"
    );

    const data = await response.json();

    document.getElementById("btc").innerText = "$" + data.bitcoin.usd;
    document.getElementById("eth").innerText = "$" + data.ethereum.usd;
    document.getElementById("sol").innerText = "$" + data.solana.usd;
    document.getElementById("bnb").innerText = "$" + data.binancecoin.usd;

  }catch(error){
    console.log("Error loading prices");
  }
}

loadPrices();
